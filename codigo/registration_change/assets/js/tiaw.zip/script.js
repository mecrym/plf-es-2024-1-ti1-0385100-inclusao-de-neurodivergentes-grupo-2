document.addEventListener('DOMContentLoaded', function() {
  // Função para carregar e processar o JSON
  fetch('data.json')
    .then(response => response.json())
    .then(data => {
      const tasks = data.tasks;
      const container = document.querySelector('.container');

      tasks.forEach(task => {
        const card = document.createElement('div');
        card.classList.add('card');

        card.innerHTML = `
          <div class="category-icon">
          </div>
          <div class="category-name">${task.category}</div>
          <div class="time-period">${task.timePeriod}</div>
          <div class="add-task">+</div>
        `;

        container.appendChild(card);
      });

      // Adicionar interatividade aos símbolos de "+"
      document.querySelectorAll('.add-task').forEach(function(button) {
        button.addEventListener('click', function() {
          alert('Este atalho leva para a tela de programação de tarefas referentes à categoria selecionada.');
        });
      });
    })
    .catch(error => console.error('Error loading JSON:', error));

  // Adicionar interatividade ao botão "Add"
  document.querySelector('.add-button').addEventListener('click', function() {
    alert('Este atalho leva para a tela de seleção de uma nova categoria de tarefas.');
  });
});
