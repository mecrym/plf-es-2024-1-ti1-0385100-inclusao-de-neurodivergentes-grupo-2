document.addEventListener("DOMContentLoaded", () => {
  const frequencyOptions = document.querySelectorAll('input[name="frequency"]');
  const daysOfWeekContainer = document.querySelector('.days-of-week');
  const nextButton = document.getElementById('next-button');

  frequencyOptions.forEach(option => {
    option.addEventListener('change', () => {
      if (option.value === "specific days of the week") {
        daysOfWeekContainer.style.display = 'block';
      } else {
        daysOfWeekContainer.style.display = 'none';
      }
    });
  });

  nextButton.addEventListener('click', () => {
    const selectedFrequency = document.querySelector('input[name="frequency"]:checked').value;
    let selectedDays = [];
    if (selectedFrequency === "specific days of the week") {
      const selectedDayCheckboxes = document.querySelectorAll('input[name="day"]:checked');
      selectedDayCheckboxes.forEach(checkbox => {
        selectedDays.push(checkbox.value);
      });
    }

    const habitData = {
      frequency: selectedFrequency,
      days: selectedDays
    };

    localStorage.setItem('habitData', JSON.stringify(habitData));
    alert('Data saved!');
  });
});
